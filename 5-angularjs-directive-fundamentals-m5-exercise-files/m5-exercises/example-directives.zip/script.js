// Code goes here

angular.module('app', []);

angular.module('app').controller('mainCtrl', function($scope) {
  $scope.people = ['Luke', 'Han', 'Anakin'];
});

